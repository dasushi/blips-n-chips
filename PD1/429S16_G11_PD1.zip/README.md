PD1: Stephen Arsenault (sjarsena) and Michael Magliocchi (mmaglioc), Group 11
Custom testbench tb_SumArray uses SumArray.x to perform brief reads and writes. 
Output is included in the form of dump.lx2 (GTKWave compatible waveform output)
and also through the included terminal log output from running a testbench in terminal_output.txt 